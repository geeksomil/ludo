let redarea = document.getElementById("redarea");
let bluearea = document.getElementById("bluearea");
let greenarea = document.getElementById("greenarea");
let grids = document.getElementsByClassName("grid");
// for (x in grids) {
//   grids[x].innerHTML = grids[x].getAttribute("id");
// }

let flag = false;
let current, n;
function clickevent(event) {
  let id = event.target.id;
  current = document.getElementById(id);
  let idx = id[2] - 1;
  for (x in allowed) {
    document
      .getElementById(allowed[x])
      .removeEventListener("click", clickevent);
  }
  let pos = arr[turn % 4].pos[idx];
  console.log(pos);
  let c = 0;
  for (let i = pos + 1; i <= pos + n; i++) {
    setTimeout(() => {
      document.getElementById(i).appendChild(current);
    }, 500 * ++c);
  }

  arr[turn % 4].changePosition(idx, n);
}
console.log(grids);
class Pawn {
  constructor(color) {
    this.color = color;
    let c = "p" + color[0];
    this.id = [c + 1, c + 2, c + 3, c + 4];
    this.pos = [-1, -1, -1, -1];
    console.log(this.id);
  }
  changePosition(pawn, x) {
    this.id[pawn] += x;
  }
  out() {
    let result = [];
    for (let i = 0; i < 4; i++) {
      if (this.pos[i] != -1) {
        result.push(this.id[i]);
      }
    }
    return result;
  }
  in() {
    let result = [];
    for (let i = 0; i < 4; i++) {
      if (this.pos[i] == -1) {
        result.push(this.id[i]);
      }
    }
    return result;
  }
}
let red = new Pawn("red");
let blue = new Pawn("blue");
let green = new Pawn("green");
let yellow = new Pawn("yellow");
let arr = [red, blue, green, yellow];
let turn = 0;
let allowed;
let button = document.getElementById("roll");
function moving() {
  n = Math.floor(Math.random() * 6) + 1;
  diceWorking(n, arr[(turn + 1) % 4].color);
  console.log(n);
  if (n == 6) {
    allowed = arr[turn % 4].id;
  } else {
    allowed = arr[turn % 4].out();
  }

  console.log(allowed);
  for (x in allowed) {
    console.log("hello" + x);
    document.getElementById(allowed[x]).addEventListener("click", clickevent);
    pawnAnimation(allowed[x], 180);
    console.log("hello" + allowed[x]);
  }
  turn++;
}
console.log($(".panel"));
document.getElementsByClassName("dice")[0].onclick = moving;
function diceWorking(rnd, color) {
  $("#dice-color").val("#000000");
  $("#dot-color").val("#ffd700");
  let x, y;
  console.log("f");
  switch (rnd) {
    case 1:
      x = 720;
      y = 810;
      break;
    case 6:
      x = 720;
      y = 990;
      break;
    default:
      x = 720 + (6 - rnd) * 90;
      y = 900;
      break;
  }
  $(".dice").css(
    "transform",
    "translateZ(-100px) rotateY(" + x + "deg) rotateX(" + y + "deg)"
  );
  $(".dot").css("background-color", color);
}
function pawnAnimation(idName, degree) {
  let idNameSelector = "#" + idName;
  console.log(idNameSelector);
  $(idNameSelector).css({ transform: "rotate(0deg)" }); // Reset rotation
  $(idNameSelector).animate(
    { deg: degree }, // Rotate to 360 degrees (1 full rotation)
    {
      duration: 1200, // Animation duration in milliseconds
      step: function (now) {
        console.log(now);
        $(this).css({
          transform: "rotate(" + now + "deg)",
          backgroundColor: "red",
        });
      },
      complete: function () {
        // Animation complete, restart the rotation
        console.log(degree);
        degree += 180;
        pawnAnimation(idName, degree);
      },
    }
  );
}
pawnAnimation("pb1", 360);
